export enum State {
  Pending = 1,
  Completed = 2,
  Failed = 3,
}
