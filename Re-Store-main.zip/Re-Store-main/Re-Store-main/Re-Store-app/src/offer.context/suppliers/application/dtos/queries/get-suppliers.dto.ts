export class GetSuppliersDto {
  public id: number;
  public firstName: string;
  public lastName: string;
  public ruc: string;
  public phone: string;
}