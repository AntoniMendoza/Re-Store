"use strict";
exports.__esModule = true;
exports.CartState = void 0;
var CartState = /** @class */ (function () {
    function CartState() {
    }
    CartState.prototype.setContext = function (cart) {
        this.cart = cart;
    };
    return CartState;
}());
exports.CartState = CartState;
