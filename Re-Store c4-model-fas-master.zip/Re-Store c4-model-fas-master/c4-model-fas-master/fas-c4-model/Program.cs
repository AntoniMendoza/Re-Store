﻿using Structurizr;
using Structurizr.Api;

namespace fas_c4_model
{
    class Program
    {
        static void Main(string[] args)
        {
            Banking();
        }

        static void Banking()
        {
            const long workspaceId = 73639;
            const string apiKey = "eb173c53-f95d-41eb-8024-e557fe2fb345";
            const string apiSecret = "e34bb863-849d-47cf-9b6a-19a3fb5a3e92";

            StructurizrClient structurizrClient = new StructurizrClient(apiKey, apiSecret);
            Workspace workspace = new Workspace("FAS C4 Model - Sistema de Monitoreo Re-Store", "Sistema de Monitoreo de ventas de productos");
            Model model = workspace.Model;
            ViewSet viewSet = workspace.Views;

            // 1. Diagrama de Contexto
            SoftwareSystem monitoringSystem = model.AddSoftwareSystem("Re-Store", "Aplicacion de venta de insumos con desperfectos superficiales a menor precio");
            SoftwareSystem googleMaps = model.AddSoftwareSystem("Delivery System", "Plataforma que ofrece una REST API de información de los productos que dispone Re-Store para realizar deliveries");
            SoftwareSystem aircraftSystem = model.AddSoftwareSystem("Pay System", "Plataforma que ofrece un API para realizar pagos.");

            Person ciudadano = model.AddPerson("Consumidor", "Ciudadano que realiza sus compras en diferentes supermercados.");
            Person periodista = model.AddPerson("Vendedor", "Persona representante de centro comercial");
            //Person developer = model.AddPerson("Developer", "Developer - Open Data.");

            ciudadano.Uses(monitoringSystem, "Realiza consultas para mantenerse al tanto de las ofertas que realiza Re-Store");
            periodista.Uses(monitoringSystem, "Realiza consultas para mantenerse al tanto de los precios de los productos");
            //developer.Uses(monitoringSystem, "Realiza consultas a la REST API para mantenerse al tanto de la planificación de los vuelos hasta la llegada del lote de vacunas al Perú");
            monitoringSystem.Uses(aircraftSystem, "Permite realizar pago de los productos");
            monitoringSystem.Uses(googleMaps, "Realiza entrega de los productos");
            
            SystemContextView contextView = viewSet.CreateSystemContextView(monitoringSystem, "Contexto", "Diagrama de contexto");
            contextView.PaperSize = PaperSize.A4_Landscape;
            contextView.AddAllSoftwareSystems();
            contextView.AddAllPeople();

            // Tags
            monitoringSystem.AddTags("SistemaMonitoreo");
            googleMaps.AddTags("GoogleMaps");
            aircraftSystem.AddTags("AircraftSystem");
            ciudadano.AddTags("Ciudadano");
            periodista.AddTags("Periodista");
           // developer.AddTags("Developer");
            
            Styles styles = viewSet.Configuration.Styles;
            styles.Add(new ElementStyle("Ciudadano") { Background = "#0a60ff", Color = "#ffffff", Shape = Shape.Person });
            styles.Add(new ElementStyle("Periodista") { Background = "#08427b", Color = "#ffffff", Shape = Shape.Person });
            styles.Add(new ElementStyle("Developer") { Background = "#facc2e", Shape = Shape.Robot });
            styles.Add(new ElementStyle("SistemaMonitoreo") { Background = "#008f39", Color = "#ffffff", Shape = Shape.RoundedBox });
            styles.Add(new ElementStyle("GoogleMaps") { Background = "#90714c", Color = "#ffffff", Shape = Shape.RoundedBox });
            styles.Add(new ElementStyle("AircraftSystem") { Background = "#2f95c7", Color = "#ffffff", Shape = Shape.RoundedBox });

            // 2. Diagrama de Contenedores
            Container mobileApplication = monitoringSystem.AddContainer("Mobile App", "Permite a los usuarios visualizar el estado de los pedidos de los productos", "Flutter");
            Container webApplication = monitoringSystem.AddContainer("Web App", "Permite al usuario interactuar con el entorno del negocio, comprar y recervasr productos.", "Flutter Web");
            Container landingPage = monitoringSystem.AddContainer("Landing Page", "", "Flutter Web");
            Container apiGateway = monitoringSystem.AddContainer("API Gateway", "API Gateway", "Spring Boot port 8080");
            Container flightPlanningContext = monitoringSystem.AddContainer("Offers Context", "Bounded Context del Microservicio de Ofertas de venta", "Spring Boot port 8081");
            Container airportContext = monitoringSystem.AddContainer("Shoping Car Context", "Bounded Context del Microservicio de Recerva de Productos", "Spring Boot port 8082");
            Container aircraftInventoryContext = monitoringSystem.AddContainer("Purchase Record Context", "Bounded Context del Microservicio de Compra de Productos", "Spring Boot port 8083");
            Container vaccinesInventoryContext = monitoringSystem.AddContainer("Payment Context", "Bounded Context del Microservicio de Pagos de usuarios", "Spring Boot port 8084");
         Container monitoringContext = monitoringSystem.AddContainer("CheckOut  Process Context", "Bounded Context del Microservicio de supervición, para ver si el pago fue efectuado", "Spring Boot port 8085");
            Container messageBus = monitoringSystem.AddContainer("Bus de Mensajes en Cluster de Alta Disponibilidad", "Transporte de eventos del dominio.", "RabbitMQ");
            Container flightPlanningContextDatabase = monitoringSystem.AddContainer("Offers Context DB", "", "Oracle");
            Container airportContextDatabase = monitoringSystem.AddContainer("Shoping Car Context DB", "", "Oracle");
            Container aircraftInventoryContextDatabase = monitoringSystem.AddContainer("Purchase Record Context DB", "", "Oracle");
            Container vaccinesInventoryContextDatabase = monitoringSystem.AddContainer("Payment Context DB", "", "Oracle");
            Container monitoringContextDatabase = monitoringSystem.AddContainer("CheckOut  Process Context DB", "", "Oracle");
            Container monitoringContextReplicaDatabase = monitoringSystem.AddContainer("Look for Context DB Replica", "", "Oracle");
            Container monitoringContextReactiveDatabase = monitoringSystem.AddContainer("Look for  Context Reactive DB", "", "Firebase Cloud Firestore");
            
            ciudadano.Uses(mobileApplication, "Consulta");
            ciudadano.Uses(webApplication, "Consulta");
            ciudadano.Uses(landingPage, "Consulta");
            periodista.Uses(mobileApplication, "Consulta");
            periodista.Uses(webApplication, "Consulta");
            periodista.Uses(landingPage, "Consulta");
            mobileApplication.Uses(apiGateway, "API Request", "JSON/HTTPS");
            webApplication.Uses(apiGateway, "API Request", "JSON/HTTPS");
            //developer.Uses(apiGateway, "API Request", "JSON/HTTPS");
            apiGateway.Uses(flightPlanningContext, "API Request", "JSON/HTTPS");
            apiGateway.Uses(airportContext, "API Request", "JSON/HTTPS");
            apiGateway.Uses(aircraftInventoryContext, "API Request", "JSON/HTTPS");
            apiGateway.Uses(vaccinesInventoryContext, "API Request", "JSON/HTTPS");
            apiGateway.Uses(monitoringContext, "API Request", "JSON/HTTPS");
            flightPlanningContext.Uses(messageBus, "Publica y consume eventos del dominio");
            flightPlanningContext.Uses(flightPlanningContextDatabase, "", "JDBC");
            airportContext.Uses(messageBus, "Publica y consume eventos del dominio");
            airportContext.Uses(airportContextDatabase, "", "JDBC");
            aircraftInventoryContext.Uses(messageBus, "Publica y consume eventos del dominio");
            aircraftInventoryContext.Uses(aircraftInventoryContextDatabase, "", "JDBC");
            vaccinesInventoryContext.Uses(messageBus, "Publica y consume eventos del dominio");
            vaccinesInventoryContext.Uses(vaccinesInventoryContextDatabase, "", "JDBC");
            monitoringContext.Uses(messageBus, "Publica y consume eventos del dominio");
            monitoringContext.Uses(monitoringContextDatabase, "", "JDBC");
            monitoringContext.Uses(monitoringContextReplicaDatabase, "", "JDBC");
            monitoringContext.Uses(monitoringContextReactiveDatabase, "", "");
            monitoringContextDatabase.Uses(monitoringContextReplicaDatabase, "Replica");
            monitoringContext.Uses(googleMaps, "API Request", "JSON/HTTPS");
            monitoringContext.Uses(aircraftSystem, "API Request", "JSON/HTTPS");

            // Tags
            mobileApplication.AddTags("MobileApp");
            webApplication.AddTags("WebApp");
            landingPage.AddTags("LandingPage");
            apiGateway.AddTags("APIGateway");
            flightPlanningContext.AddTags("OfferContext");
            flightPlanningContextDatabase.AddTags("OffersContextDatabase");
            airportContext.AddTags("ShopingCarContext");
            airportContextDatabase.AddTags("ShopingCarContextDatabase");
            aircraftInventoryContext.AddTags("PurchaseRecordContext");
            aircraftInventoryContextDatabase.AddTags("PurchaseRecordContextDatabase");
            vaccinesInventoryContext.AddTags("´PaymentContext");
            vaccinesInventoryContextDatabase.AddTags("PaymentContextDatabase");
            monitoringContext.AddTags("CheckOutProcessContext");
            monitoringContextDatabase.AddTags("CheckoutProcessContextDatabase");
            monitoringContextReplicaDatabase.AddTags("LookForContextReactiveDB");
            monitoringContextReactiveDatabase.AddTags("LookForContextReactiveDB");
            messageBus.AddTags("MessageBus");
            
            styles.Add(new ElementStyle("MobileApp") { Background = "#9d33d6", Color = "#ffffff", Shape = Shape.MobileDevicePortrait, Icon = "" });
            styles.Add(new ElementStyle("WebApp") { Background = "#9d33d6", Color = "#ffffff", Shape = Shape.WebBrowser, Icon = "" });
            styles.Add(new ElementStyle("LandingPage") { Background = "#929000", Color = "#ffffff", Shape = Shape.WebBrowser, Icon = "" });
            styles.Add(new ElementStyle("APIGateway") { Shape = Shape.RoundedBox, Background = "#0000ff", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("OffersContext") { Shape = Shape.Hexagon, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("OfferContextDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("ShopingCarContext") { Shape = Shape.Hexagon, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("ShopingCarContextDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("PurchaseRecordContext") { Shape = Shape.Hexagon, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("PurchaseRecordContextDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("PaymentContext") { Shape = Shape.Hexagon, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("PaymentContextDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("CheckOutProcessContext") { Shape = Shape.Hexagon, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("CheckOutProcessContextDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("CheckOutProcessContextReplicaDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("CheckOutProcesstReactiveDatabase") { Shape = Shape.Cylinder, Background = "#ff0000", Color = "#ffffff", Icon = "" });
            styles.Add(new ElementStyle("MessageBus") { Width = 850, Background = "#fd8208", Color = "#ffffff", Shape = Shape.Pipe, Icon = "" });

            ContainerView containerView = viewSet.CreateContainerView(monitoringSystem, "Contenedor", "Diagrama de contenedores");
            contextView.PaperSize = PaperSize.A4_Landscape;
            containerView.AddAllElements();

            // 3. Diagrama de Componentes
            Component domainLayer = monitoringContext.AddComponent("Domain Layer", "", "Spring Boot");
            Component monitoringController = monitoringContext.AddComponent("Monitoring Controller", "REST API endpoints de monitoreo.", "Spring Boot REST Controller");
            Component monitoringApplicationService = monitoringContext.AddComponent("Monitoring Application Service", "Provee métodos para el monitoreo, pertenece a la capa Application de DDD", "Spring Component");
            Component flightRepository = monitoringContext.AddComponent("Store Repository", "Información de los productos", "Spring Component");
                Component vaccineLoteRepository = monitoringContext.AddComponent("Información de la disponibilidad de productos", "Información de lote de productos", "Spring Component");
            Component locationRepository = monitoringContext.AddComponent("Location Repository", "Ubicación del productos", "Spring Component");
            Component aircraftSystemFacade = monitoringContext.AddComponent("Store System Facade", "", "Spring Component");

            apiGateway.Uses(monitoringController, "", "JSON/HTTPS");
            monitoringController.Uses(monitoringApplicationService, "Invoca métodos de monitoreo");
            monitoringController.Uses(aircraftSystemFacade, "Usa");
            monitoringApplicationService.Uses(domainLayer, "Usa", "");
            monitoringApplicationService.Uses(flightRepository, "", "JDBC");
            monitoringApplicationService.Uses(vaccineLoteRepository, "", "JDBC");
            monitoringApplicationService.Uses(locationRepository, "", "JDBC");
            flightRepository.Uses(monitoringContextDatabase, "", "JDBC");
            vaccineLoteRepository.Uses(monitoringContextDatabase, "", "JDBC");
            locationRepository.Uses(monitoringContextDatabase, "", "JDBC");
            locationRepository.Uses(monitoringContextReactiveDatabase, "", "");
            locationRepository.Uses(googleMaps, "", "JSON/HTTPS");
            aircraftSystemFacade.Uses(aircraftSystem, "JSON/HTTPS");
            
            // Tags
            domainLayer.AddTags("DomainLayer");
            monitoringController.AddTags("MonitoringController");
            monitoringApplicationService.AddTags("MonitoringApplicationService");
            flightRepository.AddTags("StoreRepository");
            vaccineLoteRepository.AddTags("ProductLoteRepository");
            locationRepository.AddTags("LocationRepository");
            aircraftSystemFacade.AddTags("StoreSystemFacade");
            
            styles.Add(new ElementStyle("DomainLayer") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("MonitoringController") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("MonitoringApplicationService") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("MonitoringDomainModel") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("StoreStatus") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("StoreRepository") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("ProductLoteRepository") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("LocationRepository") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });
            styles.Add(new ElementStyle("StoreSystemFacade") { Shape = Shape.Component, Background = "#facc2e", Icon = "" });

            ComponentView componentView = viewSet.CreateComponentView(monitoringContext, "Components", "Component Diagram");
            componentView.PaperSize = PaperSize.A4_Landscape;
            componentView.Add(mobileApplication);
            componentView.Add(webApplication);
            componentView.Add(apiGateway);
            componentView.Add(monitoringContextDatabase);
            componentView.Add(monitoringContextReactiveDatabase);
            componentView.Add(aircraftSystem);
            componentView.Add(googleMaps);
            componentView.AddAllComponents();

            structurizrClient.UnlockWorkspace(workspaceId);
            structurizrClient.PutWorkspace(workspaceId, workspace);
        }
    }
}